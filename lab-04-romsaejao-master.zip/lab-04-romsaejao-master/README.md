# lab 04 : JavaScript HTML DOM Programming 

ให้นักศึกษาสร้าง Web App “Todo list” อย่างง่าย โดยใช้ภาษา Html CSS และ JavaScript ซึ่งมีรายละเอียดตาม pdf ด้านล่างนี้

https://o365cmu-my.sharepoint.com/:b:/g/personal/chayanin_s_cmu_ac_th1/EaBAYEIn59NOhpdkgSD-3FMB-ZozjDyQR2UIjeeMM1L_DQ?e=0Vdbl2
